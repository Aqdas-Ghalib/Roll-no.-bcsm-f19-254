const BASE_URL="https://fakestoreapi.com/"
export const PRODUCTS_BY_CATEGORY=`${BASE_URL}products/category` //jewelery
export const PRODUCTS_LIST=`${BASE_URL}products?limit=7` //jewelery

 