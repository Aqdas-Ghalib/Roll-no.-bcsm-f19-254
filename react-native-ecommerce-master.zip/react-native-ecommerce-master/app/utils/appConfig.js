export const ANDROID_APP_ID= "ca-app-pub-6766214386933283~7422509112"
export const ANDROID_FULL_PAGE_AD_ID=  "ca-app-pub-6766214386933283/6078294395"


export const APP_CURRENY={
    symbol:"$"
}
/*

App Open	ca-app-pub-3940256099942544/5662855259
Banner	ca-app-pub-3940256099942544/2934735716
Interstitial	ca-app-pub-3940256099942544/4411468910
Interstitial Video	ca-app-pub-3940256099942544/5135589807
Rewarded	ca-app-pub-3940256099942544/1712485313
Rewarded Interstitial	ca-app-pub-3940256099942544/6978759866
Native Advanced	ca-app-pub-3940256099942544/3986624511
Native Advanced Video	ca-app-pub-3940256099942544/2521693316


* */